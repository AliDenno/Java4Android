package mooc.vandy.java4android.diamonds.ui;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;

import mooc.vandy.java4android.diamonds.R;

import mooc.vandy.java4android.diamonds.logic.Logic;
import mooc.vandy.java4android.diamonds.logic.LogicInterface;

/**
 * The main UI of the App.
 */
public class MainActivity 
       extends AppCompatActivity 
       implements OutputInterface {
    /**
     * String for LOGGING.
     */
    private final static String LOG_TAG =
        MainActivity.class.getCanonicalName();

    /**
     * Logic Instance.
     */
    private LogicInterface mLogic;

    /**
     * EditText that stores the output.
     */
    private EditText mOutput;

    /**
     * The Spinner (drop down selector) that you choose which size to
     * use.
     */
    private Spinner mSizeSpinner;

    /**
     * Button the user presses to perform the computation.
     */
    private Button mProcessButton;

    /**
     * This 'Adapts' the Array of CharSequence to make it useable by
     * the mMathSpinner.
     */
    private ArrayAdapter<CharSequence> mAdapter;

    /**
     * Called when the activity is starting.
     *
     * Similar to 'main' in C/C++/Standalone Java
     * @param savedInstanceState
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // required
        super.onCreate(savedInstanceState);

        // create a new 'Logic' instance.
        mLogic = new Logic(this);

        // setup the UI.
        initializeUI();
    }

    /**
     * This method sets up/gets reference to the UI components
     */
    private void initializeUI(){
        // Set the layout.
        setContentView(R.layout.activity_main);

        // Initialize the views.
        mOutput = (EditText) findViewById(R.id.outputET);
        mSizeSpinner = (Spinner) findViewById(R.id.sizeSpinner);
        mProcessButton = (Button) findViewById(R.id.button);

        // Initialize the adapter.
        mAdapter =
            ArrayAdapter.createFromResource(this,
                                            R.array.diamondSizes,
                                            android.R.layout.simple_spinner_item);
        mAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        // Associate the ArrayAdapter with the Spinner.
        mSizeSpinner.setAdapter(mAdapter);
    }

    /**
     * Called when Button is Pressed.
     *
     * @param buttonPress
     */
    public void buttonPressed(View buttonPress) {
        resetText();
        mLogic.process(Integer.valueOf(mSizeSpinner.getSelectedItem().toString()));
    }

    /**
     * Add @a string to the EditText.
     */
    private void addToEditText(String string) {
        mOutput.setText("" + mOutput.getText() + string);
    }

    /**
     * Return the string.
     */
    @Override
    public String getString() {
        return mOutput.getText().toString();
    }

    /**
     * This prints to the output a string
     * @param text
     */
    @Override
    public void print(String text) {
        Log.d(LOG_TAG, "print(String)");
        addToEditText(text);
    }

    /**
     * This prints to the output a char
     * @param _char
     */
    @Override
    public void print(char _char) {
        print("" + _char);
    }

    /**
     * This prints to the screen a string then a new line
     * @param text
     */
    @Override
    public void println(String text) {
        Log.d(LOG_TAG,"println(String)");
        addToEditText(text + "\n");
    }

    /**
     * This prints to the screen a char then a new line
     * @param _char
     */
    @Override
    public void println(char _char) {
        println("" + _char);
    }

    /**
     * Reset the on-screen output (EditText box)
     */
    @Override
    public void resetText() {
        mOutput.setText("");
    }

    /**
     * Log @a logtext to the logcat.
     */
    @Override
    public void log(String logtext) {
        Log.d(Logic.TAG, logtext);
    }
}
